﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class Elevator : MonoBehaviour {
    public float firstFloor;
    public float secondFloor;
    public float thirdFloor;
    public float Duration;

    private void OnTriggerStay(Collider other)
    {

        if (other.tag == "Player")
        {
            if (Input.GetKey(KeyCode.Z))
            {
                if(gameObject.transform.position.y < secondFloor)
                {
                    transform.DOMoveY(secondFloor, Duration);
                }

                else
                {
                    transform.DOMoveY(thirdFloor, Duration);
                }
            }

            if (Input.GetKey(KeyCode.X))
            {

                if (gameObject.transform.position.y > secondFloor)
                {
                    transform.DOMoveY(secondFloor, Duration);
                }

                else
                {
                    transform.DOMoveY(firstFloor, Duration);
                }
            }
        }
    }
}
